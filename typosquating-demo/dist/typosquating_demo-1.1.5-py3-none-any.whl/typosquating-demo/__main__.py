from typosquating import get_info

def main():
  url = 'https://typosquating-server.herokuapp.com/'
  get_info(url)


if __name__ == '__main__':
  main()